-- Safe to run against an existing QuotePilot database; keeps users and quotes.
CREATE TABLE IF NOT EXISTS billing_cycles (
 subscription_id TEXT PRIMARY KEY, period_start INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS credit_purchases (
 session_id TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), credits INTEGER NOT NULL CHECK(credits>0)
);
CREATE TRIGGER IF NOT EXISTS grant_purchased_credits AFTER INSERT ON credit_purchases
BEGIN
 UPDATE users SET credits=credits+NEW.credits WHERE id=NEW.user_id;
END;
-- Quote insertion and balance deduction run as one SQLite statement/transaction.
CREATE TRIGGER IF NOT EXISTS check_quote_balance BEFORE INSERT ON quotes
BEGIN
 SELECT CASE WHEN NOT EXISTS (
  SELECT 1 FROM users WHERE id=NEW.user_id AND (
   (NEW.credit_source='subscription' AND plan!='none' AND subscription_status='active'
    AND julianday(reset_at)>julianday('now') AND monthly_used<monthly_limit)
   OR (NEW.credit_source='credit' AND credits>0)
  )
 ) THEN RAISE(ABORT,'NO_QUOTE_CREDITS') END;
END;
CREATE TRIGGER IF NOT EXISTS debit_quote_balance AFTER INSERT ON quotes
BEGIN
 UPDATE users SET monthly_used=monthly_used+CASE WHEN NEW.credit_source='subscription' THEN 1 ELSE 0 END,
 credits=credits-CASE WHEN NEW.credit_source='credit' THEN 1 ELSE 0 END WHERE id=NEW.user_id;
END;
CREATE TABLE IF NOT EXISTS pending_checkouts (
 session_id TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),created_at TEXT NOT NULL DEFAULT(datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_pending_checkout_user ON pending_checkouts(user_id);
CREATE TABLE IF NOT EXISTS auth_limits (bucket TEXT PRIMARY KEY,count INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS billing_settings (key TEXT PRIMARY KEY,value TEXT NOT NULL);
INSERT OR IGNORE INTO billing_settings(key,value) VALUES('credit_ledger_started',strftime('%s','now'));
