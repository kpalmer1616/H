// Uses Wrangler's own login and token storage. Never paste account secrets into chat.
import {spawnSync} from 'node:child_process';
import {writeFileSync} from 'node:fs';
const wrangler=process.platform==='win32'?'node_modules/.bin/wrangler.cmd':'node_modules/.bin/wrangler';
function run(args,capture=false){const result=spawnSync(wrangler,args,{encoding:'utf8',stdio:capture?['inherit','pipe','inherit']:'inherit',env:{...process.env,CLOUDFLARE_ACCOUNT_ID:'f6482243ebf1056b4556111250f4b27c'}});if(result.status!==0)throw Error(`Wrangler ${args[0]} failed. Complete Cloudflare login, then run this command again.`);return result.stdout;}
try {
 const raw=run(['d1','list','--json'],true);
 const databases=JSON.parse(raw);
 const db=databases.find(d=>d.name==='quotepilot-db');
 if(!db?.uuid)throw Error('The existing quotepilot-db database was not found in the expected Cloudflare account.');
 const config={name:'yellow-feather-7be1',account_id:'f6482243ebf1056b4556111250f4b27c',main:'src/worker.js',compatibility_date:'2026-10-01',keep_vars:true,assets:{directory:'./public',binding:'ASSETS',run_worker_first:['/api/*']},d1_databases:[{binding:'DB',database_name:'quotepilot-db',database_id:db.uuid}]};
 writeFileSync('wrangler.deploy.json',JSON.stringify(config,null,2)+'\n');
 run(['d1','execute','quotepilot-db','--remote','--config','wrangler.deploy.json','--file','sql/schema.sql','--yes']);
 run(['d1','execute','quotepilot-db','--remote','--config','wrangler.deploy.json','--file','sql/billing-migration.sql','--yes']);
 run(['deploy','--config','wrangler.deploy.json']);
 console.log('Published. Open your dashboard and click Refresh billing to recover the existing test subscription.');
} catch(error){console.error(error.message);process.exitCode=1;}
