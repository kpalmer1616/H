import {Miniflare,convertV4MiniflareOptions} from 'miniflare';
import {build} from 'esbuild';
import {readFileSync,mkdirSync} from 'node:fs';
import assert from 'node:assert/strict';
mkdirSync('dist',{recursive:true});
await build({entryPoints:['src/worker.js'],bundle:true,format:'esm',outfile:'dist/worker.js',platform:'browser',target:'es2022'});
const mf=new Miniflare(convertV4MiniflareOptions({modules:true,scriptPath:'dist/worker.js',compatibilityDate:'2026-10-01',d1Databases:['DB']}));
try{
 const db=await mf.getD1Database('DB');
 // D1 exec accepts one SQL statement per line. Preserve trigger bodies on one line.
 const schema=readFileSync('sql/schema.sql','utf8');
 for(const statement of schema.split(';').map(s=>s.trim()).filter(Boolean))await db.prepare(statement).run();
 const migration=readFileSync('sql/billing-migration.sql','utf8');
 let statement='',trigger=false;
 for(const line of migration.split('\n')){
  if(line.trim().startsWith('--')||!line.trim())continue;
  if(line.trim().startsWith('CREATE TRIGGER'))trigger=true;
  statement+=line+'\n';
  if((trigger&&line.trim()==='END;')||(!trigger&&line.trim().endsWith(';'))){await db.prepare(statement).run();statement='';trigger=false;}
 }

 const payload={email:'runtime@example.com',password:'runtime-test-password-only'};
 const authReq=(path,body,cookie)=>mf.dispatchFetch('https://app.example/api/'+path,{method:body?'POST':'GET',headers:{origin:'https://app.example',cookie:cookie||'','content-type':'application/json'},body:body?JSON.stringify(body):undefined});
 const register=await authReq('register',payload);assert.equal(register.status,200,await register.clone().text());
 const cookie=register.headers.get('set-cookie').split(';')[0];
 const me=await authReq('me',null,cookie);assert.equal((await me.json()).user.credits,0);
 await db.prepare('UPDATE users SET credits=1 WHERE email=?').bind(payload.email).run();
 const quote={requestId:crypto.randomUUID(),customer:'Runtime test',service:'Detail',hours:2,rate:30,materials:10,overhead:5,margin:25};
 const first=await authReq('quotes',quote,cookie);assert.equal(first.status,200,await first.clone().text());
 assert.equal((await first.json()).quote.price,100);
 assert.equal((await authReq('quotes',quote,cookie)).status,200);
 assert.equal((await authReq('quotes',{...quote,requestId:crypto.randomUUID()},cookie)).status,402);
 assert.equal((await authReq('login',payload)).status,200);
 console.log('Cloudflare runtime + D1 smoke passed: registration, login, session, quote calculation, retry, and quota cap.');
}finally{await mf.dispose();}
