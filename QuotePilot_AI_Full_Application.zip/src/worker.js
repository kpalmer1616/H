import {PACKS,PLANS,priceFor,stripe,syncBilling,webhook,BillingError} from './billing.js';
const encoder=new TextEncoder();
const json=(v,status=200,headers={})=>new Response(JSON.stringify(v),{status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff',...headers}});
const fail=(message,status=400)=>json({error:message},status);
const hex=b=>Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('');
const rand=()=>crypto.randomUUID();
async function digest(value){return hex(await crypto.subtle.digest('SHA-256',encoder.encode(value)));}
async function passwordHash(pass,salt){const key=await crypto.subtle.importKey('raw',encoder.encode(pass),'PBKDF2',false,['deriveBits']);return hex(await crypto.subtle.deriveBits({name:'PBKDF2',salt:encoder.encode(salt),iterations:100000,hash:'SHA-256'},key,256));}
function cookie(req){const m=(req.headers.get('cookie')||'').match(/(?:^|;\s*)qp_session=([^;]+)/);return m?m[1]:null;}
async function currentUser(req,env){const token=cookie(req);if(!token)return null;return await env.DB.prepare("SELECT u.* FROM users u JOIN sessions s ON s.user_id=u.id WHERE s.token_hash=? AND s.expires_at > datetime('now')").bind(await digest(token)).first();}
function sessionCookie(token,maxAge=604800){return `qp_session=${token}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${maxAge}`;}
async function createSession(env,id){const token=rand()+rand();await env.DB.prepare("INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,datetime('now','+7 days'))").bind(await digest(token),id).run();return sessionCookie(token);}
async function body(req){const raw=await req.text();if(raw.length>16000)throw new BillingError('Request too large',413);try{return JSON.parse(raw);}catch{throw new BillingError('Invalid JSON',400);}}
const emailOk=e=>typeof e==='string'&&e.length<=254&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
const userView=u=>({email:u.email,plan:u.plan,status:u.subscription_status,monthlyLimit:u.reset_at&&Date.parse(u.reset_at)<=Date.now()?0:u.monthly_limit,monthlyUsed:u.monthly_used,credits:u.credits,resetAt:u.reset_at});
function originOk(req){const origin=req.headers.get('origin');return !!origin&&origin===new URL(req.url).origin;}
async function authRateLimit(req,env){
 const window=Math.floor(Date.now()/900000);
 const bucket=String(window)+':'+await digest(req.headers.get('cf-connecting-ip')||'local');
 const result=await env.DB.prepare('INSERT INTO auth_limits(bucket,count) VALUES(?,1) ON CONFLICT(bucket) DO UPDATE SET count=count+1 RETURNING count').bind(bucket).first();
 await env.DB.prepare('DELETE FROM auth_limits WHERE bucket<?').bind(String(window-1)+':').run();
 return result.count<=30;
}
async function route(req,env){const url=new URL(req.url);const path=url.pathname;if(path==='/api/stripe/webhook'&&req.method==='POST')return webhook(req,env);
if(!path.startsWith('/api/'))return env.ASSETS ? env.ASSETS.fetch(req) : new Response('Static assets are not attached to this deployment.',{status:503});
if(req.method==='POST'&&!originOk(req))return fail('Invalid origin',403);
if(path==='/api/products'&&req.method==='GET')return json({products:Object.keys({...PLANS,...PACKS}).filter(sku=>priceFor(env,sku)),testMode:String(env.STRIPE_SECRET_KEY||'').includes('_test_')});
if(['/api/register','/api/login'].includes(path)&&req.method==='POST'&&!(await authRateLimit(req,env)))return fail('Too many sign-in attempts. Try again in 15 minutes.',429);
if(path==='/api/register'&&req.method==='POST'){
 const b=await body(req);const email=String(b.email||'').trim().toLowerCase(),pass=b.password;
 if(!emailOk(email)||typeof pass!=='string'||pass.length<12||pass.length>128)return fail('Enter a valid email and password of at least 12 characters');
 const salt=rand(),hash=await passwordHash(pass,salt),id=rand();try{await env.DB.prepare('INSERT INTO users(id,email,password_hash,salt) VALUES(?,?,?,?)').bind(id,email,hash,salt).run();}catch(e){if(String(e.message).includes('UNIQUE'))return fail('Email already registered',409);throw e;}
 return json({user:{email,plan:'none',monthlyLimit:0,monthlyUsed:0,credits:0}},200,{'set-cookie':await createSession(env,id)});
}
if(path==='/api/login'&&req.method==='POST'){
 const b=await body(req);const email=String(b.email||'').trim().toLowerCase();if(!emailOk(email)||typeof b.password!=='string'||b.password.length>128)return fail('Invalid email or password',401);const u=await env.DB.prepare('SELECT * FROM users WHERE email=?').bind(email).first();
 if(!u||typeof b.password!=='string'||await passwordHash(b.password,u.salt)!==u.password_hash)return fail('Invalid email or password',401);
 return json({user:userView(u)},200,{'set-cookie':await createSession(env,u.id)});
}
const u=await currentUser(req,env);if(!u)return fail('Please sign in',401);
if(path==='/api/me'&&req.method==='GET')return json({user:userView(u)});
if(path==='/api/billing/sync'&&req.method==='POST'){const b=await body(req);const result=await syncBilling(env,u,b.sessionId);const fresh=await env.DB.prepare('SELECT * FROM users WHERE id=?').bind(u.id).first();return json({...result,user:userView(fresh)});}
if(path==='/api/logout'&&req.method==='POST'){const t=cookie(req);await env.DB.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await digest(t)).run();return json({ok:true},200,{'set-cookie':sessionCookie('',0)});}
if(path==='/api/quotes'&&req.method==='GET'){
 const q=await env.DB.prepare('SELECT id,customer_name,service,cost,price,margin,credit_source,created_at FROM quotes WHERE user_id=? ORDER BY created_at DESC LIMIT 50').bind(u.id).all();return json({quotes:q.results});
}
if(path==='/api/quotes'&&req.method==='POST'){
 const b=await body(req);const customer=String(b.customer||'').trim(),service=String(b.service||'').trim();
 const n=['hours','rate','materials','overhead','margin'].map(k=>Number(b[k]));
 if(!customer||customer.length>120||!service||service.length>120||n.some(x=>!Number.isFinite(x))||n.slice(0,4).some(x=>x<0||x>1000000)||n[4]<0||n[4]>90)return fail('Check quote details and margin (0–90%)');
 const [hours,rate,materials,overhead,margin]=n;const cost=Math.round((hours*rate+materials+overhead)*100)/100;const price=Math.round(cost/(1-margin/100)*100)/100;
 if(cost<=0||price>100000000)return fail('Enter positive, reasonable costs');
 const id=b.requestId||rand();
 if(!/^[a-zA-Z0-9-]{20,80}$/.test(id))return fail('Invalid request reference');
 const old=await env.DB.prepare('SELECT * FROM quotes WHERE id=? AND user_id=?').bind(id,u.id).first();
 if(!old){
 try{await env.DB.prepare(`INSERT INTO quotes(id,user_id,customer_name,service,hours,hourly_rate,materials,overhead,margin,cost,price,credit_source)
 SELECT ?,id,?,?,?,?,?,?,?,?,?,CASE WHEN plan!='none' AND subscription_status='active' AND julianday(reset_at)>julianday('now') AND monthly_used<monthly_limit THEN 'subscription' ELSE 'credit' END
 FROM users WHERE id=? AND NOT EXISTS(SELECT 1 FROM quotes WHERE id=?)`)
 .bind(id,customer,service,hours,rate,materials,overhead,margin,cost,price,u.id,id).run();}
 catch(e){if(String(e.message).includes('NO_QUOTE_CREDITS'))return fail('No quote credits remaining. Buy credits or subscribe.',402);throw e;}
 }
 const saved=await env.DB.prepare('SELECT * FROM quotes WHERE id=? AND user_id=?').bind(id,u.id).first();
 if(!saved)return fail('Quote reference already used',409);
 return json({quote:{id:saved.id,customer:saved.customer_name,service:saved.service,cost:saved.cost,price:saved.price,margin:saved.margin,source:saved.credit_source}});
}
if(path==='/api/checkout'&&req.method==='POST'){
 const b=await body(req);const sku=String(b.sku||'');const plan=PLANS[sku],pack=PACKS[sku];if(!plan&&!pack)return fail('Unknown product');
 const price=priceFor(env,sku); if(!price)return fail('Payment product not configured',503);
 if(plan){await syncBilling(env,u);const fresh=await env.DB.prepare('SELECT * FROM users WHERE id=?').bind(u.id).first();Object.assign(u,fresh);}
 const configured=await stripe(env,'prices/'+encodeURIComponent(price));
 if(!configured.active||configured.currency!=='usd'||configured.unit_amount!==(plan||pack).cents||!!configured.recurring!==!!plan||(plan&&(configured.recurring.interval!=='month'||configured.recurring.interval_count!==1)))return fail('Payment price does not match this plan. Contact support.',503);
 const mode=plan?'subscription':'payment';const params={'mode':mode,'line_items[0][price]':price,'line_items[0][quantity]':'1','success_url':url.origin+'/dashboard?payment=success&session_id={CHECKOUT_SESSION_ID}','cancel_url':url.origin+'/pricing.html?payment=cancel','client_reference_id':u.id,'metadata[user_id]':u.id,'metadata[kind]':sku};
 if(u.stripe_customer_id)params.customer=u.stripe_customer_id;else params.customer_email=u.email;
 if(plan){params['subscription_data[metadata][user_id]']=u.id;params['subscription_data[metadata][kind]']=sku;}
 if(pack&&u.stripe_customer_id)params.customer=u.stripe_customer_id;
 if(plan&&u.subscription_id&&['active','trialing','past_due'].includes(u.subscription_status))return fail('Manage your current subscription before starting another',409);
 const checkout=await stripe(env,'checkout/sessions',params);await env.DB.prepare('INSERT INTO pending_checkouts(session_id,user_id) VALUES(?,?)').bind(checkout.id,u.id).run();return json({url:checkout.url});
}
if(path==='/api/billing-portal'&&req.method==='POST'){
 if(!u.stripe_customer_id)return fail('No billing account found',400);
 const portal=await stripe(env,'billing_portal/sessions',{customer:u.stripe_customer_id,return_url:url.origin+'/dashboard.html'});return json({url:portal.url});
}
return fail('Not found',404);
}
export default {async fetch(req,env){try{return await route(req,env);}catch(err){console.error('QuotePilot error',err);return fail(err instanceof BillingError?err.message:'Something went wrong. Please try again.',err instanceof BillingError?err.status:500);}}};
