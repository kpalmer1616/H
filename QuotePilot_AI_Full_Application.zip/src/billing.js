// All entitlements come from Stripe responses fetched by the server.
export const PACKS = {pack5:{credits:5,cents:499},pack20:{credits:20,cents:1499},pack50:{credits:50,cents:2999}};
export const PLANS = {pro:{limit:25,cents:999},business:{limit:100,cents:1999}};
export const priceFor = (env, sku) => String(env['STRIPE_PRICE_'+sku.toUpperCase()] || '').trim();
export class BillingError extends Error { constructor(message,status=503){super(message);this.status=status;} }
export async function stripe(env, path, params, idempotencyKey) {
  const key=String(env.STRIPE_SECRET_KEY||'').trim();
  if(!/^sk_(test|live)_/.test(key)&&!/^rk_(test|live)_/.test(key)) throw new BillingError('Billing needs a valid Stripe secret key.');
  const headers={authorization:`Bearer ${key}`,'Stripe-Version':'2025-02-24.acacia'};
  if(params) headers['content-type']='application/x-www-form-urlencoded';
  if(idempotencyKey) headers['Idempotency-Key']=idempotencyKey;
  const r=await fetch('https://api.stripe.com/v1/'+path,{method:params?'POST':'GET',headers,body:params?new URLSearchParams(params):undefined,signal:AbortSignal.timeout(15000)});
  const data=await r.json();
  if(!r.ok) {
    console.error('Stripe request failed',r.status,data.error?.code||'unknown');
    throw new BillingError(r.status===429?'Billing is busy. Please try again shortly.':'Billing could not be verified. Please try again or contact support.');
  }
  if(typeof data.livemode==='boolean' && data.livemode!==key.includes('_live_')) throw new BillingError('Stripe mode mismatch.');
  return data;
}
const objectId = value => typeof value==='string'?value:value?.id;
export async function applySubscription(env, id, userId) {
  const sub=await stripe(env,'subscriptions/'+encodeURIComponent(id)+'?expand[]=latest_invoice');
  if(sub.metadata?.user_id!==userId) throw new BillingError('Subscription does not belong to this account.',403);
  const user=await env.DB.prepare('SELECT * FROM users WHERE id=?').bind(userId).first();
  if(!user) throw new BillingError('Account not found.',404);
  // A delayed event from an older subscription cannot replace a current active one.
  if(user.subscription_id && user.subscription_id!==sub.id && user.subscription_status==='active') return;
  const item=sub.items?.data?.[0];
  const kind=Object.keys(PLANS).find(k=>priceFor(env,k) && item?.price?.id===priceFor(env,k));
  let invoice=sub.latest_invoice;
  if(typeof invoice==='string') invoice=await stripe(env,'invoices/'+encodeURIComponent(invoice));
  const start=item?.current_period_start||sub.current_period_start;
  const end=item?.current_period_end||sub.current_period_end;
  const paid=invoice?.status==='paid' && invoice?.paid!==false && invoice?.amount_paid>0;
  const active=!!kind && sub.status==='active' && paid && Number.isFinite(start) && end>Date.now()/1000;
  const customer=objectId(sub.customer);
  const statements=[];
  if(active) {
    // The cycle is tracked separately: webhook duplicates and dashboard refreshes
    // must never replenish the same paid monthly allowance twice.
    statements.push(env.DB.prepare(`UPDATE users SET monthly_used=CASE
      WHEN subscription_id=? AND (EXISTS(SELECT 1 FROM billing_cycles WHERE subscription_id=? AND period_start>=?) OR (monthly_limit>0 AND NOT EXISTS(SELECT 1 FROM billing_cycles WHERE subscription_id=?))) THEN monthly_used ELSE 0 END,
      plan=?,monthly_limit=?,subscription_status=?,subscription_id=?,stripe_customer_id=?,reset_at=? WHERE id=? AND NOT EXISTS(SELECT 1 FROM billing_cycles WHERE subscription_id=? AND period_start>?)`)
      .bind(sub.id,sub.id,start,sub.id,kind,PLANS[kind].limit,sub.status,sub.id,customer,new Date(end*1000).toISOString(),userId,sub.id,start));
    statements.push(env.DB.prepare(`INSERT INTO billing_cycles(subscription_id,period_start) VALUES(?,?)
      ON CONFLICT(subscription_id) DO UPDATE SET period_start=MAX(period_start,excluded.period_start)`).bind(sub.id,start));
  } else {
    statements.push(env.DB.prepare(`UPDATE users SET plan='none',monthly_limit=0,subscription_status=?,subscription_id=?,stripe_customer_id=?,reset_at=? WHERE id=?`)
      .bind(sub.status,sub.id,customer,end?new Date(end*1000).toISOString():null,userId));
  }
  await env.DB.batch(statements);
}
export async function applyCheckout(env,id,userId) {
  if(!/^cs_(test|live)_[A-Za-z0-9]+$/.test(id||'')) throw new BillingError('Invalid checkout reference.',400);
  const session=await stripe(env,'checkout/sessions/'+encodeURIComponent(id)+'?expand[]=line_items');
  if(session.metadata?.user_id!==userId || session.client_reference_id!==userId) throw new BillingError('Checkout does not belong to this account.',403);
  if(session.status!=='complete' || session.payment_status!=='paid') return {pending:true};
  const sku=session.metadata?.kind;
  if(session.mode==='subscription' && PLANS[sku] && session.subscription) {
    await applySubscription(env,objectId(session.subscription),userId);
    return {pending:false};
  }
  const pack=PACKS[sku];
  const lines=session.line_items?.data;
  if(session.mode!=='payment'||!pack||session.currency!=='usd'||session.amount_total!==pack.cents||lines?.length!==1||lines[0].price?.id!==priceFor(env,sku)||lines[0].quantity!==1)
    throw new BillingError('Checkout product could not be verified.',409);
  const cutover=await env.DB.prepare("SELECT value FROM billing_settings WHERE key='credit_ledger_started'").first();
  if(session.created<Number(cutover?.value||0)) throw new BillingError('This earlier credit purchase needs a support review to avoid granting it twice.',409);
  // A unique session ID and SQL trigger make the credit grant exactly once.
  await env.DB.prepare('INSERT OR IGNORE INTO credit_purchases(session_id,user_id,credits) VALUES(?,?,?)').bind(session.id,userId,pack.credits).run();
  await env.DB.prepare('UPDATE users SET stripe_customer_id=? WHERE id=?').bind(objectId(session.customer),userId).run();
  return {pending:false};
}
export async function syncBilling(env,user,sessionId) {
  if(sessionId) {const result=await applyCheckout(env,sessionId,user.id);if(!result.pending)await env.DB.prepare('DELETE FROM pending_checkouts WHERE session_id=? AND user_id=?').bind(sessionId,user.id).run();return result;}
  const pending=await env.DB.prepare('SELECT session_id FROM pending_checkouts WHERE user_id=? ORDER BY created_at DESC LIMIT 10').bind(user.id).all();
  let recoveredPurchase=false;
  for(const row of pending.results){const result=await applyCheckout(env,row.session_id,user.id);if(!result.pending){recoveredPurchase=true;await env.DB.prepare('DELETE FROM pending_checkouts WHERE session_id=?').bind(row.session_id).run();}}
  if(user.subscription_id) {await applySubscription(env,user.subscription_id,user.id);return {pending:false};}
  // Recover legacy checkouts made before the success URL included a session ID.
  // Metadata is server-written at checkout; an email match alone never grants access.
  const query=`metadata['user_id']:'${user.id.replace(/[^a-zA-Z0-9-]/g,'')}' AND status:'active'`;
  const list=await stripe(env,'subscriptions/search?'+new URLSearchParams({query,limit:'10'}));
  const sub=list.data?.find(s=>s.metadata?.user_id===user.id);
  if(sub) await applySubscription(env,sub.id,user.id);
  return {pending:!sub&&!recoveredPurchase};
}
export async function webhook(req,env) {
  if(!env.STRIPE_WEBHOOK_SECRET) throw new BillingError('Webhook is not configured.');
  const raw=await req.text();
  if(raw.length>1000000) return new Response('Payload too large',{status:413});
  const fields=(req.headers.get('stripe-signature')||'').split(',').map(s=>s.trim().split('='));
  const ts=fields.find(([k])=>k==='t')?.[1];
  if(!/^\d+$/.test(ts||'') || Math.abs(Date.now()/1000-Number(ts))>300) return new Response('Invalid signature',{status:400});
  const enc=new TextEncoder();
  const key=await crypto.subtle.importKey('raw',enc.encode(String(env.STRIPE_WEBHOOK_SECRET).trim()),{name:'HMAC',hash:'SHA-256'},false,['verify']);
  let valid=false;
  for(const [type,value] of fields) if(type==='v1' && /^[a-f0-9]{64}$/.test(value||'')) {
    const bytes=Uint8Array.from(value.match(/../g),s=>parseInt(s,16));
    if(await crypto.subtle.verify('HMAC',key,bytes,enc.encode(ts+'.'+raw))) valid=true;
  }
  if(!valid) return new Response('Invalid signature',{status:400});
  const event=JSON.parse(raw), obj=event.data?.object;
  if(!event.id||!obj) return new Response('Invalid event',{status:400});
  if(await env.DB.prepare('SELECT id FROM stripe_events WHERE id=?').bind(event.id).first()) return Response.json({received:true});
  if(['checkout.session.completed','checkout.session.async_payment_succeeded'].includes(event.type) && obj.metadata?.user_id)
    await applyCheckout(env,obj.id,obj.metadata.user_id);
  if(['customer.subscription.created','customer.subscription.updated','customer.subscription.deleted'].includes(event.type) && obj.metadata?.user_id)
    await applySubscription(env,obj.id,obj.metadata.user_id);
  if(['invoice.paid','invoice.payment_failed','invoice.payment_succeeded'].includes(event.type)) {
    const subId=objectId(obj.subscription)||objectId(obj.parent?.subscription_details?.subscription);
    if(subId){const sub=await stripe(env,'subscriptions/'+encodeURIComponent(subId));if(sub.metadata?.user_id) await applySubscription(env,subId,sub.metadata.user_id);}
  }
  await env.DB.prepare('INSERT OR IGNORE INTO stripe_events(id) VALUES(?)').bind(event.id).run();
  return Response.json({received:true});
}
