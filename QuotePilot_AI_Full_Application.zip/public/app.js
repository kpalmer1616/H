const $=id=>document.getElementById(id);
const money=n=>new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(n);
async function api(path,method='GET',payload){
 const res=await fetch('/api/'+path,{method,headers:{'content-type':'application/json'},credentials:'same-origin',body:payload?JSON.stringify(payload):undefined});
 const data=await res.json();if(!res.ok){const e=Error(data.error||'Request failed');e.status=res.status;throw e;}return data;
}
function message(t,error=false){const el=$('notice');if(el){el.textContent=t;el.className='notice '+(error?'error':'ok');}}
async function auth(action){try{await api(action,'POST',{email:$('email').value,password:$('password').value});location.href='/dashboard';}catch(e){message(e.message,true);}}
function showUser(user){$('who').textContent=user.email;$('plan').textContent=user.plan==='none'?'No subscription':user.plan.toUpperCase()+' · '+user.status;$('remaining').textContent=Math.max(0,user.monthlyLimit-user.monthlyUsed);$('credits').textContent=user.credits;}
async function loadDashboard(){try{
 const {user}=await api('me');showUser(user);
 const {quotes}=await api('quotes');$('history').replaceChildren(...quotes.map(q=>{const tr=document.createElement('tr');for(const value of [new Date(q.created_at+'Z').toLocaleDateString(),q.customer_name,q.service,money(q.price),q.credit_source]){const td=document.createElement('td');td.textContent=value;tr.append(td);}return tr;}));
 }catch(e){if(e.status===401)location.href='/login';else message(e.message,true);}
}
async function refreshBilling(){const button=$('refreshBilling');if(button)button.disabled=true;try{
 message('Checking your payment with Stripe…');
 const params=new URLSearchParams(location.search);
 const r=await api('billing/sync','POST',{sessionId:params.get('session_id')||undefined});
 showUser(r.user);
 message(r.pending?'No active subscription found yet. If you just paid, wait a moment and refresh billing again.':'Billing updated. Your available quotes are shown above.');
 if(!r.pending&&params.has('payment'))history.replaceState({},'',location.pathname);
 }catch(e){if(e.status===401)location.href='/login';else message(e.message,true);}finally{if(button)button.disabled=false;}
}
async function initDashboard(){await loadDashboard();if(new URLSearchParams(location.search).get('payment')==='success')await refreshBilling();}
let quoteRequest=null;
async function generateQuote(ev){ev.preventDefault();const button=ev.submitter||ev.target.querySelector('button');if(button.disabled)return;button.disabled=true;
 try{
 const b={customer:$('customer').value,service:$('service').value,hours:Number($('hours').value),rate:Number($('rate').value),materials:Number($('materials').value),overhead:Number($('overhead').value),margin:Number($('margin').value)};
 const fingerprint=JSON.stringify(b);if(!quoteRequest||quoteRequest.fingerprint!==fingerprint)quoteRequest={fingerprint,id:crypto.randomUUID()};
 const {quote}=await api('quotes','POST',{...b,requestId:quoteRequest.id});quoteRequest=null;
 $('quoteResult').textContent=`Quote saved for ${quote.customer}: ${money(quote.price)} (estimated costs ${money(quote.cost)}). One ${quote.source} quote used.`;message('Quote created.');await loadDashboard();
 }catch(e){message(e.message,true);}finally{button.disabled=false;}
}
let openingCheckout=false;
async function checkout(sku){if(openingCheckout)return;openingCheckout=true;try{message('Opening secure checkout…');const r=await api('checkout','POST',{sku});location.href=r.url;}catch(e){if(e.status===401)location.href='/login';else message(e.message,true);}finally{openingCheckout=false;}}
async function loadPricing(){try{const r=await api('products');for(const button of document.querySelectorAll('[data-sku]')){button.disabled=!r.products.includes(button.dataset.sku);if(button.disabled)button.textContent='Coming soon';}if(r.testMode)message('Test checkout — payments here are simulated.');}catch(e){message('Pricing is temporarily unavailable. Please refresh.',true);}}
async function portal(){try{const r=await api('billing-portal','POST',{});location.href=r.url;}catch(e){message(e.message,true);}}
async function logout(){try{await api('logout','POST',{});location.href='/';}catch(e){message(e.message,true);}}
window.qp={auth,loadDashboard,initDashboard,refreshBilling,generateQuote,checkout,portal,logout,loadPricing};
