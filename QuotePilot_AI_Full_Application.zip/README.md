# QuotePilot AI — billing recovery update

This is the complete revised source project. It has not been deployed to the live Worker.

## Publish to the existing Cloudflare Worker

On a computer with Node.js 24 or later, open a terminal in this folder:

```sh
npm ci
npx wrangler login
npm run deploy:setup
```

The deployment command uses the existing Cloudflare account and Worker
`yellow-feather-7be1`, finds `quotepilot-db` automatically, applies a non-destructive
migration, and deploys the Worker together with the website assets. Existing
users, quote history, variables and secrets are preserved. It stops if the database
cannot be found; it never creates or deletes a database. Wrangler's login page is
where account authentication happens. Never put secret keys in this project or chat.

After deployment open the signed-in dashboard and click **Refresh billing**. This
can recover the existing paid test Pro subscription through its server-written
user metadata. Search results can take a short time to appear in Stripe.

This project uses multiple source files. Deploy the whole project; copying only
`worker.js` into the dashboard editor will omit the billing module and migration.

## What changed

- Workers-compatible PBKDF2 iteration count, preserving the password format used
  by the current deployed app.
- Server-side checkout verification on return, pending-checkout recovery and a
  manual billing refresh. Ownership is checked against the signed-in user.
- Stripe webhook HMAC verification, duplicate-safe credit grants, and monthly
  cycle tracking so refreshes or repeated events cannot reset used quotes.
- Subscription data is fetched fresh from Stripe instead of trusting delayed
  event snapshots. Both older and newer invoice/subscription field layouts are read.
- Credits are deducted in the same database transaction that inserts a quote.
  A retried request with the same request ID returns the saved quote without charging again.
- Expired monthly allowances cannot be spent; prepaid credits remain usable.
- Checkout validates the configured price, currency, amount and billing interval.
  Unconfigured products display Coming soon. Test mode is labeled.
- Temporary server failures no longer sign the user out. Sign-in endpoints have
  a basic IP-based request limit, and malformed requests are rejected.
- Static assets are attached explicitly, avoiding the undefined ASSETS.fetch error.

## Required existing Cloudflare configuration

| Name | Type | Value |
| --- | --- | --- |
| DB | D1 binding | quotepilot-db |
| STRIPE_SECRET_KEY | Secret | Actual Stripe secret key from the same mode as prices |
| STRIPE_WEBHOOK_SECRET | Secret | Signing secret for the matching webhook endpoint |
| STRIPE_PRICE_PRO | Text | Currently test price: price_1US2UWC8jt9OEVqSbe7slJxL |
| STRIPE_PRICE_BUSINESS | Text, optional | $19.99 USD monthly / 100 quotes |
| STRIPE_PRICE_PACK5 | Text, optional | $4.99 USD once / 5 quotes |
| STRIPE_PRICE_PACK20 | Text, optional | $14.99 USD once / 20 quotes |
| STRIPE_PRICE_PACK50 | Text, optional | $29.99 USD once / 50 quotes |

Webhook URL:
`https://yellow-feather-7be1.kpalmer1616.workers.dev/api/stripe/webhook`

Subscribe to `checkout.session.completed`, `checkout.session.async_payment_succeeded`,
`customer.subscription.created`, `customer.subscription.updated`,
`customer.subscription.deleted`, `invoice.paid` and `invoice.payment_failed`.
Set up the Stripe customer portal separately if Manage billing is not enabled.
Keep test keys, prices and webhook destination together. Live billing requires a
separate matching live configuration; this update does not switch the app live.

The first run establishes the new prepaid purchase ledger. Credit purchases made
before this migration require a manual support review, because the original app
never stored their checkout session IDs; granting them again could duplicate credits.
Existing credit balances are kept. Subscriptions made before this update can be recovered.

## Local development and verification

```sh
npm ci
npm run db:local
npm run dev
npm run check
npm test
npm run test:runtime
npx wrangler deploy --dry-run --outdir dist
```

Local database commands use the placeholder remote UUID only as a local binding;
`deploy:setup` resolves the actual database ID for remote deployment.
Tests use Node's SQLite engine, mocked Stripe responses and signed webhook payloads.
They cover paid activation, unpaid/expired access, renewals, duplicate grants,
ownership, quote retry/concurrency, transactional rollback, auth and webhook signatures.
They do not prove the current live account settings or webhook delivery are correct.

## Remaining launch decisions

The included privacy and terms pages remain drafts. Business identity, support
contact, refund policy and tax settings must be supplied by the owner before
accepting real customers. The app remains a cost-and-margin quote calculator:
no external AI model, exports, email verification, password reset or MFA has been
added in this update. Subscription quantities are one seat; discounts, free trials,
multiple simultaneous plans and custom billing models are not supported.
